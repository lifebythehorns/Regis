<?php // login.php 
    $hn = 'localhost';
    $db = 'converter';
    $un = 'lance';
    $pw = 'Kance8457';
?>