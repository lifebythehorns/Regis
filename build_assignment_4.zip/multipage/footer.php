<div class="insert-post-ads1" style="margin-top:20px;">

</div>
</div>
</body> <center>  <font size="3" color="green"> <div id="Foo"><div class="scroll-left">
 Have a nice day, Dr. Lotfy! :D 
</div> 
</html>

